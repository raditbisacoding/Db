const express = require('express');
const fetch = require('node-fetch');
const bodyParser = require('body-parser');
const session = require('express-session');
const app = express();
const path = require("path");
const PORT = process.env.PORT || 5000;
// =======================================
// CONFIGURATION
// =======================================
const GITHUB_OWNER = "username_github";
const GITHUB_REPO = "namarepo";
const FILE_PATH = "namafile.json";
const GITHUB_TOKEN = "apitoken_github_lu"; // Pastikan token ini masih valid
const CONTACT_OWNER = "https://t.me/Xskycode";
const API_TITLE = "Skyzopedia Access";

// Passwords
const ADMIN_PASSWORD = "2";
const USER_PASSWORD = "1";
// =======================================

const settings = {
  contact_whatsapp: CONTACT_OWNER,
  api_title: API_TITLE
};

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(session({
  secret: 'secret-key-skyzopedia-2026',
  resave: false,
  saveUninitialized: true
}));

const GITHUB_API_URL = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${FILE_PATH}`;

// Helper: Get Settings
app.get('/set', (req, res) => res.json(settings));

// Helper: Fetch Data from GitHub
async function fetchData() {
  try {
    const res = await fetch(GITHUB_API_URL, {
      headers: { 'Authorization': `token ${GITHUB_TOKEN}` }
    });
    const json = await res.json();
    if (!json.content) throw new Error("No content found");
    const content = Buffer.from(json.content, 'base64').toString('utf-8');
    return JSON.parse(content);
  } catch (error) {
    console.error("Error fetching data:", error);
    return []; 
  }
}

// Helper: Update Data to GitHub
async function updateData(newData) {
  try {
    const current = await fetch(GITHUB_API_URL, {
      headers: { 'Authorization': `token ${GITHUB_TOKEN}` }
    }).then(res => res.json());

    const base64Content = Buffer.from(JSON.stringify(newData, null, 2)).toString('base64');

    await fetch(GITHUB_API_URL, {
      method: 'PUT',
      headers: {
        'Authorization': `token ${GITHUB_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: 'Update database.json via Skyzopedia',
        content: base64Content,
        sha: current.sha
      })
    });
  } catch (error) {
    console.error("Error updating data:", error);
  }
}

// Middleware: Check Admin Auth
function authMiddleware(req, res, next) {
  if (req.session && req.session.isAdmin) {
    next();
  } else {
    res.redirect('/login');
  }
}

// Middleware: Check User/Auth Auth
function authMiddlewareUser(req, res, next) {
  if (req.session && (req.session.isUser || req.session.isAdmin)) {
    next();
  } else {
    res.redirect('/login');
  }
}

// =======================================
// USER ROUTES
// =======================================

// User Dashboard
app.get('/', authMiddlewareUser, async (req, res) => {
  const message = req.session.message;
  req.session.message = null;
  const data = await fetchData();
  res.render('user', { message, data, isAdmin: req.session.isAdmin });
});

// Add Number (User & Admin)
app.post('/add', authMiddlewareUser, async (req, res) => {
  let { number } = req.body;
  const data = await fetchData();
  number = number.replace(/[^0-9]/g, "");
  
  if (number.length < 8 || number.length > 15) {
    req.session.message = 'Invalid number (must be 8-15 digits)';
    return res.redirect('/');
  }
  
  const alreadyExists = data.find(item => item.number === number);
  if (alreadyExists) {
    req.session.message = 'Number already registered';
    return res.redirect('/');
  }

  data.push({ number, status: 'active' });
  await updateData(data);
  req.session.message = 'Number added successfully ✓';
  res.redirect('/');
});

// User Login Page
app.get('/login', (req, res) => {
  if (req.session.isAdmin) return res.redirect('/admin');
  if (req.session.isUser) return res.redirect('/');
  
  const message = req.session.message;
  req.session.message = null;
  res.render('login', { message });
});

// User Login Action
app.post('/login', (req, res) => {
  const { password } = req.body;
  
  // Check Admin Password First
  if (password === ADMIN_PASSWORD) {
    req.session.isAdmin = true;
    req.session.isUser = false;
    return res.redirect('/admin'); 
  } 
  
  // Check User Password
  if (password === USER_PASSWORD) {
    req.session.isUser = true;
    req.session.isAdmin = false;
    return res.redirect('/'); 
  } 

  // Invalid Password
  req.session.message = 'Incorrect password!';
  res.redirect('/login');
});

app.get('/logout-user', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// =======================================
// ADMIN ROUTES
// =======================================

// Admin Dashboard (Stats & Nav)
app.get('/admin', authMiddleware, async (req, res) => {
  const data = await fetchData();
  const message = req.session.message;
  req.session.message = null;
  res.render('dashboard', { data, message });
});

// Admin Add Number
app.post('/admin-add', authMiddleware, async (req, res) => {
  let { number } = req.body;
  const data = await fetchData();
  number = number.replace(/[^0-9]/g, "");
  
  if (number.length < 8 || number.length > 15) {
    req.session.message = 'Invalid number (must be 8-15 digits)';
    return res.redirect('/admin');
  }
  
  const alreadyExists = data.find(item => item.number === number);
  if (alreadyExists) {
    req.session.message = 'Number already registered';
    return res.redirect('/admin');
  }

  data.push({ number, status: 'active' });
  await updateData(data);
  req.session.message = 'Number added successfully ✓';
  res.redirect('/admin');
});

// Admin Delete Number
app.post('/delete', authMiddleware, async (req, res) => {
  const { number } = req.body;
  let data = await fetchData();
  data = data.filter(item => item.number !== number);
  await updateData(data);
  req.session.message = 'Number deleted successfully ✓';
  res.redirect('/admin');
});

// Admin Blacklist Number
app.post('/blacklist', authMiddleware, async (req, res) => {
  const { number } = req.body;
  let data = await fetchData();
  data = data.map(item => item.number === number ? { ...item, status: 'blacklist' } : item);
  await updateData(data);
  req.session.message = 'Number blacklisted successfully ✓';
  res.redirect('/admin');
});

// Admin Whitelist (Unblock) Number
app.post('/whitelist', authMiddleware, async (req, res) => {
  const { number } = req.body;
  let data = await fetchData();
  data = data.map(item => item.number === number ? { ...item, status: 'active' } : item);
  await updateData(data);
  req.session.message = 'Number unblocked successfully ✓';
  res.redirect('/admin');
});

// Admin Logout
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// =======================================
// API ENDPOINTS
// =======================================

app.post('/whatsapp', async (req, res) => {
  try {
    const current = await fetch(GITHUB_API_URL, {
      headers: { 'Authorization': `token ${GITHUB_TOKEN}` }
    }).then(res => res.json());

    const content = Buffer.from(current.content, "base64").toString("utf-8");
    const jsonData = JSON.parse(content);
    res.json(jsonData);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch data" });
  }
});

app.get('/whatsapp', async (req, res) => {
  try {
    const current = await fetch(GITHUB_API_URL, {
      headers: { 'Authorization': `token ${GITHUB_TOKEN}` }
    }).then(res => res.json());

    const content = Buffer.from(current.content, "base64").toString("utf-8");
    const jsonData = JSON.parse(content);
    res.json(jsonData);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch data" });
  }
});

app.get('/raw', async (req, res) => {
  res.json([]);
});

// Start Server
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
